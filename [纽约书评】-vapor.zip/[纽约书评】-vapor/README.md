# Paper-media
advanced learning in Python

## 主要技术实现
- **scrapy框架** ：快速爬取大量文本信息；
- **导入mysql** ：存储大量数据，方便团队合作共享；
- **worldcloud** ：敬请期待，要搞一个大事情！

[网站链接](http://www.nybooks.com/daily/)
![post](./选区_040.png)
